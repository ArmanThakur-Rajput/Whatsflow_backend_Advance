/**
 * visitorDateNotifier.js
 *
 * Do alag cron jobs chalate hain:
 *
 *  1. EVE NOTIFICATION  — har raat 9 baje IST
 *     Kal jis lead ka visitorDate hai unhe ek din pehle remind karta hai.
 *
 *  2. DAY-OF NOTIFICATION — har subah 8 baje IST
 *     Aaj jis lead ka visitorDate hai unhe same-day remind karta hai.
 *
 * Har notification mein:
 *   - Title : lead ka naam
 *   - Body  : lead ka phone number + context (kal / aaj)
 *   - data  : { leadId } — frontend ise click pe lead screen open karne ke liye use kare
 *
 * Notification kise bhejte hain:
 *   - Lead ka assignedTo employee (agar set hai)
 *   - Us tenant ke saare active admins
 *   (duplicates automatically skip hote hain agar admin aur employee ek hi ho)
 */

const cron = require('node-cron');
const Lead = require('../models/Lead.model');
const User = require('../models/User.model');
const Notification = require('../models/Notification.model');
const sendPushNotification = require('./sendPushNotification');

// ─── Helpers ─────────────────────────────────────────────────────────────────

const MONTHS = {
  Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5,
  Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11,
};

/**
 * Lead model mein visitorDate "DD MMM YYYY" (e.g. "21 Aug 2026") format mein
 * stored hai.  Ise parse karke ek Date object return karta hai (local midnight
 * IST), ya null agar format galat ho.
 */
function parseVisitorDate(str) {
  if (!str || typeof str !== 'string') return null;
  const parts = str.trim().split(/\s+/);
  if (parts.length !== 3) return null;
  const [day, mon, year] = parts;
  const monthIdx = MONTHS[mon];
  if (monthIdx === undefined) return null;
  const d = new Date(+year, monthIdx, +day);
  if (isNaN(d.getTime())) return null;
  return d;
}

/**
 * Aaj ki date ko "DD MMM YYYY" format mein return karta hai (IST).
 * Yahi format Lead.visitorDate ke saath compare hoga.
 */
function todayFormatted() {
  return new Date().toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
    timeZone: 'Asia/Kolkata',
  }); // "21 Aug 2026"
}

/**
 * N din baad ki date "DD MMM YYYY" format mein return karta hai (IST).
 */
function daysFromNowFormatted(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
    timeZone: 'Asia/Kolkata',
  });
}

// ─── Core logic ──────────────────────────────────────────────────────────────

/**
 * `targetDateStr`  — "DD MMM YYYY" string jis date ke leads dhundhne hain
 * `context`        — "tomorrow" ya "today" (notification body ke liye)
 */
async function sendVisitorDateNotifications(targetDateStr, context) {
  console.log(`[VisitorNotifier] Running for ${context} (${targetDateStr})`);

  // Sirf wo leads jinka visitorDate match karta ho aur deleted nahi hain
  const leads = await Lead.find({
    visitorDate: targetDateStr,
    isDeleted: false,
  }).select('_id name phone tenantId assignedTo').lean();

  if (!leads.length) {
    console.log(`[VisitorNotifier] No leads found for ${targetDateStr}`);
    return;
  }

  console.log(`[VisitorNotifier] ${leads.length} lead(s) found for ${targetDateStr}`);

  for (const lead of leads) {
    try {
      // Is tenant ke saare active admins collect karo
      const admins = await User.find({
        tenantId: lead.tenantId,
        role: 'admin',
        isActive: true,
      }).select('_id pushTokens').lean();

      // Recipients: admins + assigned employee (if any), unique by _id
      const recipientMap = new Map();
      for (const admin of admins) {
        recipientMap.set(String(admin._id), admin);
      }

      if (lead.assignedTo) {
        const emp = await User.findOne({
          _id: lead.assignedTo,
          tenantId: lead.tenantId,
          isActive: true,
        }).select('_id pushTokens').lean();
        if (emp) recipientMap.set(String(emp._id), emp);
      }

      if (!recipientMap.size) continue;

      // Notification content
      const title = context === 'today'
        ? `🗓️ Visitor Today: ${lead.name}`
        : `🔔 Visitor Tomorrow: ${lead.name}`;

      const body = context === 'today'
        ? `${lead.name} (${lead.phone}) is scheduled to visit today.`
        : `${lead.name} (${lead.phone}) is scheduled to visit tomorrow.`;

      // leadId string mein dena zaroori hai — FCM data sirf strings accept karta hai
      const pushData = {
        leadId: String(lead._id),
        type: 'visitor_date_reminder',
      };

      // DB notifications insert + push bhejo
      const notifDocs = [...recipientMap.values()].map((u) => ({
        tenantId: lead.tenantId,
        user: u._id,
        title,
        message: body,
        type: 'alert',
        broadcast: false,
      }));

      await Notification.insertMany(notifDocs);

      await Promise.allSettled(
        [...recipientMap.values()]
          .filter((u) => u.pushTokens?.length)
          .map((u) => u.pushTokens.map(t => sendPushNotification(t, title, body, pushData))).flat()
      );

      console.log(
        `[VisitorNotifier] Sent for lead "${lead.name}" (${lead._id}) ` +
        `to ${recipientMap.size} recipient(s)`
      );
    } catch (err) {
      console.error(`[VisitorNotifier] Error for lead ${lead._id}:`, err.message);
    }
  }
}

// ─── Cron registration ───────────────────────────────────────────────────────

function startVisitorDateNotifier() {
  // ── 1. EVE NOTIFICATION — har raat 10:44 PM IST (17:14 UTC) ──────────────
  //    Kal ki visitor date wale leads ke liye reminder
  cron.schedule('17 21 * * *', async () => {
    const tomorrow = daysFromNowFormatted(1);
    await sendVisitorDateNotifications(tomorrow, 'tomorrow');
  }, { timezone: 'UTC' });

  // ── 2. DAY-OF NOTIFICATION — har subah 12:30 PM IST (07:00 UTC) ─────────
  //    Aaj ki visitor date wale leads ke liye reminder
  cron.schedule('0 7 * * *', async () => {
    const today = todayFormatted();
    await sendVisitorDateNotifications(today, 'today');
  }, { timezone: 'UTC' });

  console.log('[VisitorNotifier] Eve (9 PM IST) & Day-of (12:30 PM IST) crons registered');
}

module.exports = { startVisitorDateNotifier };
