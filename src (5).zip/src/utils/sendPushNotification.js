const sendPushNotification = async (pushToken, title, body, data = {}) => {
  if (!pushToken) return;

  // Expo push token format check
  if (!pushToken.startsWith('ExponentPushToken')) {
    console.warn('⚠️ Invalid Expo push token format:', pushToken);
    return;
  }

  try {
    const response = await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        to: pushToken,
        title,
        body,
        data,
        sound: 'default',
        priority: 'high',
        channelId: 'default',
      }),
    });

    const result = await response.json();

    if (result?.data?.status === 'error') {
      console.error('❌ Expo push error:', result.data.message);
    } else {
      console.log('✅ Push notification sent');
    }
  } catch (err) {
    console.error('❌ Push notification failed:', err.message);
  }
};

module.exports = sendPushNotification;
